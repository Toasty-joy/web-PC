package com.example.Lab4.controller;


import com.example.Lab4.entity.Account;
import com.example.Lab4.entity.cart;
import com.example.Lab4.repository.AccountRepository;
import com.example.Lab4.repository.productRepository;
import com.example.Lab4.repository.productRepository2;
import com.example.Lab4.repository.productRepository3;
import com.example.Lab4.service.Accountservice;
import com.example.Lab4.service.SessionService;
import jakarta.servlet.http.HttpSession;
import jakarta.websocket.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.io.File;

@Controller
public class AccountController {
    private final AccountRepository accountRepository;
    private AccountRepository account;
    private SessionService sessionService;

    @Autowired
    public AccountController(AccountRepository account, SessionService sessionService, AccountRepository accountRepository) {
        this.account = account;
        this.sessionService = sessionService;
        this.accountRepository = accountRepository;
    }

    @GetMapping("/login")
    public String login() {
        return "login";
    }

    @PostMapping("/runrun")
    public String runrun(@RequestParam("username") String username, @RequestParam("password") String password, HttpSession session, Model model) {
        Account ac = account.findByUsernameAndPassword(username, password);
        if (ac != null) {
            if (ac.isQuyen()) {
                sessionService.set("accadm", ac);
                return "redirect:/indexAdmin";
            } else {
                sessionService.set("acc", ac);
                return "redirect:/view";
            }
        } else {
            return "redirect:/login";
        }
    }

    @RequestMapping("/hienten")
    public String hienten(@RequestParam("username") String username,
                          @RequestParam("password") String password,
                          HttpSession session, Model model) {
        Account account = Accountservice.login(username, password);
        if (account != null) {
            session.setAttribute("loggedInUser", account.getFullname());
        }
        return null;
    }

    @RequestMapping("/adm/edit/{id}")
    public String edit(Model model, @PathVariable("id") int id, HttpSession session) {
        Account ca = account.findById(id).get();

        session.setAttribute("id", ca);
        return "redirect:/viewadm";
    }

    @PostMapping("/adm/create")
    public String create(@RequestParam("fullName") String fullName,
                         @RequestParam("username") String username,
                         @RequestParam("password") String password,
                         @RequestParam("quyen") String quyen) {
        Account newAccount = new Account();
        newAccount.setFullname(fullName);
        newAccount.setUsername(username);
        newAccount.setPassword(password);
        newAccount.setQuyen(newAccount.isQuyen());

        account.save(newAccount);

        return "redirect:/adm/list";
    }

    @PostMapping("adm/update")
    public String update(@RequestParam("fullName") String fullName,
                         @RequestParam("username") String username,
                         @RequestParam("password") String password,
                         @RequestParam("quyen") String quyen,
                         HttpSession session) {
        Account ca = (Account) session.getAttribute("id");

        if (ca != null) {
            ca.setFullname(fullName);
            ca.setUsername(username);
            ca.setPassword(password);
            ca.setQuyen(ca.isQuyen());

            account.save(ca);
        }

        return "redirect:/adm/list";
    }

    @GetMapping("/adm/delete/{id}")
    public String delete(@PathVariable("id") int id) {
        account.deleteById(id);
        return "redirect:/adm/list";
    }

    @GetMapping("/indexAdmin")
    public String reset() {
        sessionService.set("acc", accountRepository.findByQuyenFalse());
        return "redirect:/viewadm";
    }

    @GetMapping("/signup_view")
    public String signup_view() {
        return "signup";
    }


    @PostMapping("/signup")
    public String signup(@RequestParam String username, @RequestParam String password, @RequestParam String sdt, @RequestParam String fullname, @RequestParam String quyen, HttpSession session) {
        Account ac = new Account();
        cart cartnew = new cart();
        ac.setFullname(fullname);
        ac.setSdt(sdt);
        ac.setUsername(username);
        ac.setPassword(password);
        ac.setQuyen(quyen.equals("admin")); // Sử dụng giá trị của `quyen` để đặt quyền
        cartnew.setAccount(ac);
        ac.setCart(cartnew);

        Account rs = account.save(ac);
        if (rs != null) {
            return "redirect:/login";
        } else {
            return "redirect:/signup_view";
        }
    }

    @GetMapping("/logoutok")
    public String logoutok(HttpSession session) {
        Account ac = (Account) session.getAttribute("acc");
        if (ac != null) {
            session.removeAttribute("acc");
        }
        return "redirect:/view";
    }

    @GetMapping("/logoutok1")
    public String logoutok1(HttpSession session) {
        Account ac = (Account) session.getAttribute("accadm");
        if (ac != null) {
            session.removeAttribute("accadm");
        }
        return "redirect:/login";
    }

}



