package com.example.Lab4.controller;
import com.example.Lab4.entity.Account;
import com.example.Lab4.entity.product;
import com.example.Lab4.repository.AccountRepository;
import com.example.Lab4.repository.productRepository;
import com.example.Lab4.service.SessionService;
import com.example.Lab4.service.cartService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class AddShopController {
    private productRepository repository;
    private AccountRepository accountRepository;
    private cartService cartService;
    private SessionService sessionService;

    @Autowired
    public AddShopController(productRepository repository, AccountRepository accountRepository, cartService service, SessionService sessionService) {
        this.repository = repository;
        this.accountRepository = accountRepository;
        this.cartService = service;
        this.sessionService = sessionService;
    }

    @GetMapping("/result")
    public String result() {
        Account account = sessionService.get("acc");
        if (account != null) {
            sessionService.set("mycart", cartService.getItems(account.getId()));
            sessionService.set("totalprice", cartService.getAmount(account.getId()));
        }
        return "result";
    }

    @GetMapping("/addcart/{id}")
    public String addCart(@PathVariable int id, HttpSession session) {
        Account account = sessionService.get("acc");
        product p = repository.getById(id);
        if (account == null) {
            System.out.println("Chưa Đăng Nhập!");
            return "redirect:/login";
        }if(account.isQuyen()){
             return "redirect:/viewadm";
        }else
        {
            cartService.addItem(account.getId(), p.getId());
            System.out.println("ok");
        }
        return "redirect:/view";
    }
    @RequestMapping("/clear")
    public String clearCart() {
        cartService.clear();
        return "redirect:/result";
    }
}
