package com.example.Lab4.controller;

//import com.example.Lab4.service.ShoppingCartService;

import com.example.Lab4.repository.*;
import com.example.Lab4.service.SessionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class CartController {

    private productRepository repository;
    private productRepository2 repository2;
    private productRepository3 repository3;


    @Autowired
    public CartController(productRepository repository, productRepository2 repository2, productRepository3 repository3) {
        this.repository = repository;
        this.repository2 = repository2;
        this.repository3 = repository3;
    }

    @RequestMapping("/view")
    public String view(Model model) {
        model.addAttribute("cart", repository.findAll());
        model.addAttribute("cart2", repository2.findAll());
        model.addAttribute("cart3", repository3.findAll());
        return "redirect:/products";
    }
    @RequestMapping("/viewadm3")
    public String view3(Model model) {
        model.addAttribute("cart", repository.findAll());
        model.addAttribute("cart2", repository2.findAll());
        model.addAttribute("cart3", repository3.findAll());
        return "indexofadm";
    }
    @RequestMapping("/viewadm")
    public String view1(Model model) {
        return "indexAdmin";
    }
    @RequestMapping("/viewadm2")
    public String view2(Model model) {
        return "indexofadm";
    }
    @RequestMapping("/viewadm4")
    public String view4(Model model) {
        return "indexAdmin";
    }


}
