package com.example.Lab4.repository;

import com.example.Lab4.entity.product3;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface productRepository3 extends JpaRepository<product3, Integer> {
}
